Assignment 5
Author: Ruben Suarez Rodriguez
Net_id: jrs208
Student_id: A04052618 

Description: 	For this assignment we tasks to implement and algorithmically efficient version of object detection using the chamfer 
		distance method. In additon, for the second task, we were also tasked to implement the same method with the addition
		of skin detection to increase the correctness of our object detection function.

Note:		I ended up completing this assinment alone due to my partner dropping the course. There was no driver nor navigator.

Files: 		chamfer_search.m, skin_chamfer_search.m, draw_rectangle2.m, draw_rectangle1.m, negatives.bin, positives.bin,
		read_gray.m, canny.m, canny4.m, blur_image.m, gradient_orientations.m, nonmaxsup.m, hysthresh.m, gaussian_probability.m,
		read_double_image.m, read_double_image2.m and detect_skin.m
		**All files are necessary for program to run successfully!**

Running Times:
		chamfer_search.m: 	Elapsed time is 0.020528 seconds.
		skin_chamfer_search.m:	Elapsed time is 0.056160 seconds.

		Although skin_chamfer_search.m was significantly more accurate than chamfer_search.m, unfortunately it came at a cost
		in efficiency and speed. 
		
		

